#include "sub1.h"

int main (int argc, char *argv[])
{
  char linha[MAX_STRING] = "zenit polar";
  decripta_linha(linha);
  printf("%s", linha);
  return 0;
}
