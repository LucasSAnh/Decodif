#include "sub1.h"

int main (int argc, char *argv[])
{
  printf("%c", zenit_polar('z'));
  printf("%c", zenit_polar('e'));
  printf("%c", zenit_polar('n'));
  printf("%c", zenit_polar('i'));
  printf("%c", zenit_polar('t'));
  printf("%c", zenit_polar(' '));
  printf("%c", zenit_polar('p'));
  printf("%c", zenit_polar('o'));
  printf("%c", zenit_polar('l'));
  printf("%c", zenit_polar('a'));
  printf("%c", zenit_polar('r'));
  return 0;
}
