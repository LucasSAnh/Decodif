/* 
 * Enunciado: 
 *   Desenvolva um programa capaz de ler um arquivo de texto e decripte-o
 *   utilizando a estratégia de criptografia ZENIT - POLAR.
 *   A estratégia em questão consiste em substituir os caracteres da string 
 *   da seguinte maneira:
 *
 *            Z <-> P 
 *            E <-> O
 *            N <-> L
 *            I <-> A
 *            T <-> R
 *
 *   O programa deve manter a caixa dos caracteres lidos. Exemplo:
 *     ZeNiT -> PoLaR
 *
 *   É obrigatório implementar as funções cujos protótipos já se encontram
 *   preenchidos. Não os modifique.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_STRING 100

/* 
 * Funções de implementação OBRIGATÓRIA!! Não mude os protótipos 
 *
 */

// A função zenit_polar recebe com parametro um caractere e retorna-o 
// codificado de acordo com a estratégia zenit polar
char zenit_polar(char c);
// O procedimento decripta_linha recebe como parametro uma linha e modifica-a,
// decriptando-a de acordo com a estratégia zenit polar
void decripta_linha(char* linha);
// O procedimento ler_linha deve ler uma linha de um arquivo (arq) e armazenar
// em uma string (linha).
void ler_linha(char* linha, FILE* arq);
// O procedimento decripta arquivo deve abrir dois arquivos a partir dos nomes
// dos arquivos (nome_entrada e nome_saida). Cada linha do arquivo de entrada
// deve ser lida, decriptada e gravada no arquivo de saida
void decripta_arquivo(char* nome_entrada, char* nome_saida);

int main (int argc, char *argv[])
{
  char entrada[MAX_STRING] = "msg.txt";
  char saida[MAX_STRING] = "solucao.txt";
  decripta_arquivo(entrada,saida);
  return EXIT_SUCCESS;
}

void decripta_arquivo(char* nome_entrada, char* nome_saida) {
  FILE *entrada;
  FILE *saida;
  char str[MAX_STRING];
  entrada=fopen(nome_entrada,"r");
  saida=fopen(nome_saida,"w");
  while(1){
    ler_linha(str,entrada);
    decripta_linha(str);
    fprintf(saida, "%s\n",str);
    if(feof(entrada)) break;
     
  }
  fclose(saida);
  fclose(entrada);
}

void ler_linha(char* linha, FILE* arq) {
fgets(linha, MAX_STRING, arq);
  if((linha[strlen(linha)-1]) == '\n')
  linha[strlen(linha)-1] = '\0';

}

void decripta_linha(char* linha) {
for(int i=0;i<strlen(linha);i++){
  linha[i] = zenit_polar(linha[i]);
}
}

char zenit_polar(char c) {
  char zenit[5]="zenit";
  char polar[5]="polar";
  char zenitm[5]="ZENIT";
  char polarm[5]="POLAR";
  for(int i=0;i<5;i++){
    if(c==zenit[i]) c = polar[i];
    else if(c==polar[i]) c = zenit[i];
    else if(c==zenitm[i]) c = polarm[i];
    else if(c==polarm[i]) c = zenitm[i];
  }
  return c;
  }